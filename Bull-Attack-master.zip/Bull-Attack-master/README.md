# Bull-Attack

Installation Step....

==> apt update


==> apt upgrade


==> apt install python


==> apt install python2


==> apt install git


==> cd $HOME


==> git clone https://github.com/Bhai4You/Bull-Attack


==> cd Bull-Attack


==> chmod +x B-attack.py


==> python2 B-attack.py
